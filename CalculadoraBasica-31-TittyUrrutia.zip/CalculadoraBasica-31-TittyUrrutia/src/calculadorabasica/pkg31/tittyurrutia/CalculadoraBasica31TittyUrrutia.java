/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadorabasica.pkg31.tittyurrutia;

/**
 *
 * @author LABORATORIO
 */
public class CalculadoraBasica31TittyUrrutia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        jfmCalc holaPos=new jfmCalc();
        holaPos.setVisible(true);
    }
    
}
